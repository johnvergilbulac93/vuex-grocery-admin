(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_components_admin_pages_Contact-Us_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/admin/pages/Contact-Us.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/admin/pages/Contact-Us.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({});

/***/ }),

/***/ "./resources/js/components/admin/pages/Contact-Us.vue":
/*!************************************************************!*\
  !*** ./resources/js/components/admin/pages/Contact-Us.vue ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Contact_Us_vue_vue_type_template_id_62ab62be___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Contact-Us.vue?vue&type=template&id=62ab62be& */ "./resources/js/components/admin/pages/Contact-Us.vue?vue&type=template&id=62ab62be&");
/* harmony import */ var _Contact_Us_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Contact-Us.vue?vue&type=script&lang=js& */ "./resources/js/components/admin/pages/Contact-Us.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__.default)(
  _Contact_Us_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__.default,
  _Contact_Us_vue_vue_type_template_id_62ab62be___WEBPACK_IMPORTED_MODULE_0__.render,
  _Contact_Us_vue_vue_type_template_id_62ab62be___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/admin/pages/Contact-Us.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/admin/pages/Contact-Us.vue?vue&type=script&lang=js&":
/*!*************************************************************************************!*\
  !*** ./resources/js/components/admin/pages/Contact-Us.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Contact_Us_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Contact-Us.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/admin/pages/Contact-Us.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Contact_Us_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__.default); 

/***/ }),

/***/ "./resources/js/components/admin/pages/Contact-Us.vue?vue&type=template&id=62ab62be&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/components/admin/pages/Contact-Us.vue?vue&type=template&id=62ab62be& ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Contact_Us_vue_vue_type_template_id_62ab62be___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Contact_Us_vue_vue_type_template_id_62ab62be___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Contact_Us_vue_vue_type_template_id_62ab62be___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Contact-Us.vue?vue&type=template&id=62ab62be& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/admin/pages/Contact-Us.vue?vue&type=template&id=62ab62be&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/admin/pages/Contact-Us.vue?vue&type=template&id=62ab62be&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/admin/pages/Contact-Us.vue?vue&type=template&id=62ab62be& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: " bg-gray-50 shadow-lg p-5 rounded text-gray-800 " },
    [
      _c("div", { staticClass: "flex flex-col justify-center items-center " }, [
        _c(
          "div",
          { staticClass: "mb-5 bg-gray-100 p-2 md:w-1/2 sm:w-full  border" },
          [
            _c("label", { staticClass: " flex items-center space-x-1" }, [
              _c(
                "svg",
                {
                  staticClass: "h-6 w-6",
                  attrs: {
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor"
                  }
                },
                [
                  _c("path", {
                    attrs: {
                      "stroke-linecap": "round",
                      "stroke-linejoin": "round",
                      "stroke-width": "2",
                      d:
                        "M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                    }
                  })
                ]
              ),
              _vm._v(" "),
              _c("span", { staticClass: "tracking-wider text-lg" }, [
                _vm._v("Contact Us")
              ])
            ]),
            _vm._v(" "),
            _vm._m(0)
          ]
        )
      ])
    ]
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: " mt-5 p-2 space-y-4 " }, [
      _c("table", { staticClass: "min-w-full divide-y divide-gray-300" }, [
        _c("thead", { staticClass: "border bg-gray-100  tracking-normal" }, [
          _c("tr", { staticClass: "border" }, [
            _c(
              "th",
              { staticClass: "border p-2 text-left", attrs: { colspan: "2" } },
              [
                _c("p", { staticClass: "uppercase" }, [
                  _vm._v("FOR IT SUPPORT")
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "uppercase" }, [
                  _vm._v(
                    "\n                                    Mobile & Phone Number Directories\n                                "
                  )
                ])
              ]
            )
          ])
        ]),
        _vm._v(" "),
        _c("tbody", { staticClass: "tbody" }, [
          _c("tr", { staticClass: "tr" }, [
            _c("td", { staticClass: "td" }, [_vm._v("09190796403")]),
            _vm._v(" "),
            _c("td", { staticClass: "td" }, [_vm._v("Alturas IT - Joel Sinon")])
          ]),
          _vm._v(" "),
          _c("tr", { staticClass: "tr" }, [
            _c("td", { staticClass: "td" }, [_vm._v("09190795283")]),
            _vm._v(" "),
            _c("td", { staticClass: "td" }, [
              _vm._v("Alta Citta IT - Ivy Agohob")
            ])
          ]),
          _vm._v(" "),
          _c("tr", { staticClass: "tr" }, [
            _c("td", { staticClass: "td" }, [_vm._v("09190796485")]),
            _vm._v(" "),
            _c("td", { staticClass: "td" }, [
              _vm._v(
                "\n                                Plaza Marcela IT - Kristofferson Rodrigo\n                            "
              )
            ])
          ]),
          _vm._v(" "),
          _c("tr", { staticClass: "tr" }, [
            _c("td", { staticClass: "td" }, [_vm._v("09190793478")]),
            _vm._v(" "),
            _c("td", { staticClass: "td" }, [_vm._v("ICM IT - Roderick Go")])
          ]),
          _vm._v(" "),
          _c("tr", { staticClass: "tr" }, [
            _c("td", { staticClass: "td" }, [_vm._v("09190795697")]),
            _vm._v(" "),
            _c("td", { staticClass: "td" }, [_vm._v("Sir Berting")])
          ]),
          _vm._v(" "),
          _c("tr", { staticClass: "tr" }, [
            _c("td", { staticClass: "td" }, [_vm._v("(038) 4121065")]),
            _vm._v(" "),
            _c("td", { staticClass: "td" }, [_vm._v("PLDT Corporate IT")])
          ]),
          _vm._v(" "),
          _c("tr", { staticClass: "tr" }, [
            _c("td", { staticClass: "td" }, [_vm._v("1807")]),
            _vm._v(" "),
            _c("td", { staticClass: "td" }, [
              _vm._v("Corporate IT - Technical")
            ])
          ]),
          _vm._v(" "),
          _c("tr", { staticClass: "tr" }, [
            _c("td", { staticClass: "td" }, [_vm._v("09190796051")]),
            _vm._v(" "),
            _c("td", { staticClass: "td" }, [_vm._v("Ma'am Tina")])
          ]),
          _vm._v(" "),
          _c("tr", { staticClass: "tr" }, [
            _c("td", { staticClass: "td" }, [_vm._v("1844 / 1953")]),
            _vm._v(" "),
            _c("td", { staticClass: "td" }, [_vm._v("Corporate IT - SYSDEV")])
          ])
        ])
      ])
    ])
  }
]
render._withStripped = true



/***/ })

}]);