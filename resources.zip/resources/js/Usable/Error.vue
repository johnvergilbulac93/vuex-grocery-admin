<template>
    <p class="text-red-500 text-sm">
        <small>{{ message }}</small>
    </p>
</template>

<script>
export default {
    props: ["message"]
};
</script>
