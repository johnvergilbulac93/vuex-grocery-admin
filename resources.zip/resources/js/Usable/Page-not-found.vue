<script>
export default {
     name: 'page-not-found',
     mounted(){
          this.$router.go(-1)
     }
};
</script>
