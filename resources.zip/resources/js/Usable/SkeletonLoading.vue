<template>
    <div class="mt-5 space-y-3 animate-pulse">
        <div class="space-y-1 ">
            <div class="h-5 bg-gray-300 w-1/2 "></div>
            <div class="h-10 bg-gray-300  w-full "></div>
        </div>
        <div class="space-y-1">
            <div class="h-5 bg-gray-300  w-1/4 "></div>
            <div class="h-10 bg-gray-300  w-full "></div>
        </div>
        <div class="space-y-1">
            <div class="h-5 bg-gray-300  w-1/2 "></div>
            <div class="h-10 bg-gray-300  w-full "></div>
        </div>
        <div class="h-32 bg-gray-300  w-full "></div>
        <div class="h-32 bg-gray-300  w-full "></div>
    </div>
</template>

<script>
export default {};
</script>

