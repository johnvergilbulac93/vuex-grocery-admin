<template>
    <div class=" bg-gray-50 shadow-lg p-5 rounded text-gray-800 ">
        <div class="flex flex-col justify-center items-center ">
            <div class="mb-5 bg-gray-100 p-2 md:w-1/2 sm:w-full  border">
                <label class=" flex items-center space-x-1">
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        class="h-6 w-6"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                        />
                    </svg>
                    <span class="tracking-wider text-lg">Contact Us</span>
                </label>
                <div class=" mt-5 p-2 space-y-4 ">
                    <table class="min-w-full divide-y divide-gray-300">
                        <thead class="border bg-gray-100  tracking-normal">
                            <tr class="border">
                                <th class="border p-2 text-left" colspan="2">
                                    <p class="uppercase">FOR IT SUPPORT</p>
                                    <p class="uppercase">
                                        Mobile & Phone Number Directories
                                    </p>
                                </th>
                            </tr>
                        </thead>
                        <tbody class="tbody">
                            <tr class="tr">
                                <td class="td">09190796403</td>
                                <td class="td">Alturas IT - Joel Sinon</td>
                            </tr>
                            <tr class="tr">
                                <td class="td">09190795283</td>
                                <td class="td">Alta Citta IT - Ivy Agohob</td>
                            </tr>
                            <tr class="tr">
                                <td class="td">09190796485</td>
                                <td class="td">
                                    Plaza Marcela IT - Kristofferson Rodrigo
                                </td>
                            </tr>
                            <tr class="tr">
                                <td class="td">09190793478</td>
                                <td class="td">ICM IT - Roderick Go</td>
                            </tr>
                            <tr class="tr">
                                <td class="td">09190795697</td>
                                <td class="td">Sir Berting</td>
                            </tr>
                            <tr class="tr">
                                <td class="td">(038) 4121065</td>
                                <td class="td">PLDT Corporate IT</td>
                            </tr>
                            <tr class="tr">
                                <td class="td">1807</td>
                                <td class="td">Corporate IT - Technical</td>
                            </tr>
                            <tr class="tr">
                                <td class="td">09190796051</td>
                                <td class="td">Ma'am Tina</td>
                            </tr>
                            <tr class="tr">
                                <td class="td">1844 / 1953</td>
                                <td class="td">Corporate IT - SYSDEV</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {};
</script>

<style></style>
